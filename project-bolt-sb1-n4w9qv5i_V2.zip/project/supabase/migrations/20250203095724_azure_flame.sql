/*
  # Ajout des parcours de golf

  1. Données
    - Ajout de plusieurs parcours de golf en France
*/

INSERT INTO golf_courses (name, location) VALUES
  ('Golf du Médoc Resort', 'Le Pian-Médoc'),
  ('Golf Bordelais', 'Bordeaux'),
  ('Golf de Pessac', 'Pessac'),
  ('Golf des Graves et du Sauternais', 'Saint-Pardon-de-Conques'),
  ('Golf de Bordeaux-Lac', 'Bordeaux'),
  ('Golf d''Arcachon', 'Arcachon'),
  ('Golf de Gujan-Mestras', 'Gujan-Mestras'),
  ('Golf de Lacanau', 'Lacanau'),
  ('Golf de Moliets', 'Moliets-et-Maa'),
  ('Golf d''Hossegor', 'Hossegor');